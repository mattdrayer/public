<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once "PHPUnit/Autoload.php";
require_once "/var/www/application/FrontController.php";

class FrontControllerTest extends PHPUnit_Framework_TestCase
{

    public function testRoute() {
	$request = array(
	"HTTP_USER_AGENT" => "PHPUnit Test Runner",
	"QUERY_STRING" => "",
	"REMOTE_ADDR" => "192.168.1.1",
	"REQUEST_URI" => "/",
	);

        $frontController = new FrontController();
        $response = $frontController->route($request);
        $this->assertGreaterThan(0, count($response));
    }


}
?>