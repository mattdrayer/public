<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once "PHPUnit/Autoload.php";
require_once "/var/www/application/models/CheckIpModel.php";

class CheckIpModelTest extends PHPUnit_Framework_TestCase
{
	public function testModel() {
	
		$ipAddress = "1.2.3.4";

	        $model = new CheckIpModel();
       	 	$model->set_ipAddress($ipAddress);
		$modelIpAddress = $model->get_ipAddress();

        	$this->assertEquals($ipAddress, $modelIpAddress);
	}
}
?>