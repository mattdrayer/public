<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once "PHPUnit/Autoload.php";
require_once "/var/www/application/controllers/CheckIpController.php";

class CheckIpControllerTest extends PHPUnit_Framework_TestCase
{

    public function testHandle() {
	$request = array(
	"HTTP_USER_AGENT" => "PHPUnit Test Runner",
	"QUERY_STRING" => "",
	"REMOTE_ADDR" => "192.168.1.1",
	"REQUEST_URI" => "/",
	);

        $controller = new CheckIpController();
        $response = $controller->handle($request);
        $this->assertGreaterThan(0, count($response));
    }


}
?>