<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once "PHPUnit/Autoload.php";
require_once "/var/www/application/models/CheckIpModel.php";
require_once "/var/www/application/views/CheckIpView.php";

class CheckIpViewTest extends PHPUnit_Framework_TestCase
{

    public function testBind() {
	$model = new CheckIpModel();
	$model->set_ipAddress("1.2.3.4");
	$view = new CheckIpView();
	$response = $view->bind($model);	

        $this->assertGreaterThan(0, count($response));
	$this->assertEquals("Current IP Check: 1.2.3.4", $response["content"]);
    }


}
?>