<?php

include("/var/www/application/models/CheckIpModel.php");
include("/var/www/application/views/CheckIpView.php");
include("/var/www/application/databases/CheckIpDatabase.php");

// Specialized request controller
class CheckIpController {

	// All controllers feature this request handler operation
	// Once more controllers come along we'll evolve to the tried-and-true interface/implementation factory pattern
	function handle($request)
	{

		// Log the inbound request
		$userAgent = $request["HTTP_USER_AGENT"];
		$ipAddress = $request["REMOTE_ADDR"];
		
		// If a proxy server is brokering the request, we'll need to use the original requestor's address
		if (array_key_exists("APACHE_REQUEST_HEADERS", $request) && array_key_exists('X-Forwarded-For', $request["APACHE_REQUEST_HEADERS"])) {
			$headers = $request["APACHE_REQUEST_HEADERS"];
			$ipAddress = $headers['X-Forwarded-For'];
		} 
		$logEntry = array(
			"ipAddress" => $ipAddress,
			"userAgent" => $userAgent,
		);
		LogRequest($logEntry);

		// Now populate the model and bind to the view
		$model = new CheckIpModel();
		$model->set_ipAddress($ipAddress);
		$view = new CheckIpView();	
		$response = $view->bind($model);
		return $response;
	}
}
?>