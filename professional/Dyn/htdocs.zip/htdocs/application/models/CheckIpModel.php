<?php

// in MVC, models are essentially property bags -- controllers populate them with info and bind to views
class CheckIpModel {
	var $ipAddress; 
        function set_ipAddress($new_ipAddress) { $this->ipAddress = $new_ipAddress; }
	function get_ipAddress() { return $this->ipAddress; }
}
?>