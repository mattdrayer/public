<?php 
// The View takes information from the data model and binds it to presentation-specific elements
// In this particular implementation the elements are contained in an array and then finally
// bound to the HTML in the layout template.  Several ways to go about this in PHP.
class CheckIpView {
	function bind($model) {
		$response = array(
			"title" => "Current IP Check",
			"content" => "Current IP Check: " . $model->get_ipAddress(),
		);
		return $response;
	}
}
?>