<?php


function open_database_connection()
{
    $dbConnection = mysqli_connect('localhost', 'root', 'root', 'CheckIpLog') or die(mysql_error());
    return $dbConnection;
}

function close_database_connection($dbConnection)
{
    mysqli_close($dbConnection) or die(mysql_error()); 
}

function LogRequest($request) {
	$dbConnection = open_database_connection();

	$dateRequested = date('Y-m-d H:i:s');
	$ipAddress = $request["ipAddress"];
	$userAgent = $request["userAgent"];


	mysqli_query($dbConnection,"
		INSERT INTO RequestLog (DateRequested, IpAddress, UserAgent)
		VALUES ('$dateRequested', '$ipAddress', '$userAgent')
		");

	close_database_connection($dbConnection);
}
?>