<?php 

include("/var/www/application/controllers/CheckIpController.php");

// The FrontController is the main routing mechanism for the application (basically, the front door)
class FrontController {

	// The job of the FC is to route requests to more specialized controllers
	public function route($request) {

		// Default to 404
		$response = "Status: 404 Not Found";

		$uri = $request["REQUEST_URI"];
		$queryString = $request["QUERY_STRING"];

		// Current IP Check requests
		if ($uri == '/' || $uri == '/index.php' || (array_key_exists("action", $queryString) && $queryString["action"] == "checkip")) {
			$controller = new CheckIpController();
			$response = $controller->handle($request);
		} 

		// Return the response to the caller
		return $response;
	}
}
?>