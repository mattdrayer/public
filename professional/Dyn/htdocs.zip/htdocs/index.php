<?php
	// Error reporting flags to make debugging server config a bit easier
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	//ini_set('display_startup_errors', 1);

	// Gather up some request context and hand it off to the application for processing
	$request = $_SERVER;
	$request["APACHE_REQUEST_HEADERS"] = apache_request_headers();
	include("application/FrontController.php");
	$frontController = new FrontController();
	$response = $frontController->route($request);

	// Output the response to the screen with the layout template applied
	require "templates/layoutTemplate.php";

?>